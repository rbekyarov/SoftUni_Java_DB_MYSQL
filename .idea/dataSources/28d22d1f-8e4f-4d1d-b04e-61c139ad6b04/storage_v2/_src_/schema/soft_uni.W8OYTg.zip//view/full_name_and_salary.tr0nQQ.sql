create definer = root@localhost view full_name_and_salary as
select concat_ws(' ', `soft_uni`.`employees`.`first_name`, `soft_uni`.`employees`.`last_name`) AS `Name`,
       `soft_uni`.`employees`.`salary`                                                         AS `salary`
from `soft_uni`.`employees`
order by `soft_uni`.`employees`.`salary`;

