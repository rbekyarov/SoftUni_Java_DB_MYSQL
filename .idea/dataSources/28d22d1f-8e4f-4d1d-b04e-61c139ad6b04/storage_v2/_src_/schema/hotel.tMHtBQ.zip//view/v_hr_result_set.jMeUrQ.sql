create definer = root@localhost view v_hr_result_set as
select concat(`hotel`.`employees`.`first_name`, ' ', `hotel`.`employees`.`last_name`) AS `Full Name`,
       `hotel`.`employees`.`salary`                                                   AS `salary`
from `hotel`.`employees`
order by `hotel`.`employees`.`department_id`;

