create definer = kitkabgm_emag@localhost view inout_details as
select `kitkabgm_emag`.`oc_order_product`.`product_id` AS `product_id`,
       `kitkabgm_emag`.`oc_order_product`.`name`       AS `name`,
       `kitkabgm_emag`.`oc_order_product`.`quantity`   AS `quantity`,
       'sale_table'                                    AS `table_name`,
       `kitkabgm_emag`.`oc_order`.`date_modified`      AS `order_date`
from (`kitkabgm_emag`.`oc_order`
         join `kitkabgm_emag`.`oc_order_product`
              on ((`kitkabgm_emag`.`oc_order`.`order_id` = `kitkabgm_emag`.`oc_order_product`.`order_id`)))
where (`kitkabgm_emag`.`oc_order`.`order_status_id` = 5);

