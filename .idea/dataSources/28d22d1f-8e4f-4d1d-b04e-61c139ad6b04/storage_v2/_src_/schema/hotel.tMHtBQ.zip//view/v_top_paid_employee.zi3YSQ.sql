create definer = root@localhost view v_top_paid_employee as
select `hotel`.`employees`.`id`            AS `id`,
       `hotel`.`employees`.`first_name`    AS `first_name`,
       `hotel`.`employees`.`last_name`     AS `last_name`,
       `hotel`.`employees`.`job_title`     AS `job_title`,
       `hotel`.`employees`.`department_id` AS `department_id`,
       `hotel`.`employees`.`salary`        AS `salary`
from `hotel`.`employees`
order by `hotel`.`employees`.`salary` desc
limit 1;

