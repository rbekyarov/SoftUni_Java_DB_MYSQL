create definer = root@localhost view v_employees_hired_after_2000 as
select `soft_uni`.`employees`.`first_name` AS `first_name`, `soft_uni`.`employees`.`last_name` AS `last_name`
from `soft_uni`.`employees`
where (year(`soft_uni`.`employees`.`hire_date`) > 2000);

