create definer = kitkabgm_emag@localhost view received_orders as
select `kitkabgm_emag`.`oc_po_order`.`id`                                                                       AS `order_id`,
       `kitkabgm_emag`.`oc_po_order`.`receive_bit`                                                              AS `receive_bit`,
       `kitkabgm_emag`.`oc_po_order`.`order_date`                                                               AS `order_date`,
       `kitkabgm_emag`.`oc_po_order`.`receive_date`                                                             AS `receive_date`,
       `kitkabgm_emag`.`oc_po_product`.`id`                                                                     AS `product_id`,
       `kitkabgm_emag`.`oc_po_product`.`name`                                                                   AS `name`,
       concat(`kitkabgm_emag`.`oc_po_supplier`.`first_name`, ' ',
              `kitkabgm_emag`.`oc_po_supplier`.`last_name`)                                                     AS `sname`,
       `kitkabgm_emag`.`oc_po_product`.`quantity`                                                               AS `quantity`,
       `kitkabgm_emag`.`oc_po_product`.`received_products`                                                      AS `received_products`,
       `kitkabgm_emag`.`oc_po_receive_details`.`quantity`                                                       AS `rd_quantity`,
       `kitkabgm_emag`.`oc_po_receive_details`.`price`                                                          AS `price`,
       (`kitkabgm_emag`.`oc_po_receive_details`.`quantity` *
        `kitkabgm_emag`.`oc_po_receive_details`.`price`)                                                        AS `sprice`
from (((`kitkabgm_emag`.`oc_po_receive_details` join `kitkabgm_emag`.`oc_po_supplier` on ((
        `kitkabgm_emag`.`oc_po_receive_details`.`supplier_id` =
        `kitkabgm_emag`.`oc_po_supplier`.`id`))) join `kitkabgm_emag`.`oc_po_product` on ((
        `kitkabgm_emag`.`oc_po_product`.`id` = `kitkabgm_emag`.`oc_po_receive_details`.`product_id`)))
         join `kitkabgm_emag`.`oc_po_order`
              on ((`kitkabgm_emag`.`oc_po_order`.`id` = `kitkabgm_emag`.`oc_po_receive_details`.`order_id`)))
where ((`kitkabgm_emag`.`oc_po_order`.`delete_bit` = 1) and (`kitkabgm_emag`.`oc_po_order`.`receive_bit` = 1));

